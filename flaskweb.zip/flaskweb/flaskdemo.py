from flask import Flask,render_template,url_for
from flask_mysqldb import MySQL

app=Flask(__name__)

# app.config['MYSQL_HOST']='localhost'
# app.config['MYSQL_USER']='root'
# app.config['MYSQL_PASSWORD']=''
# app.config['MYSQL_DB']='mydb'
# mysql=MySQL(app)

# @app.route("/createacc.html")
# def web():
    # fname="Baljinder"
    # lname="Singh"
    # cur= mysql.connection.cursor()
    # cur.execute("INSERT INTO user (fname,lname) VALUES (%s %s)",(fname,lname))
    # mysql.connection.commit()
    # cur.close
    
    # return render_template("createacc.html")
@app.route("/")
def web1():


    return render_template("index.html")

@app.route("/www.google.com")
def back1():
    name ="Hacker'z Eye "
    return render_template("www.google.com", name2=name)

@app.route("/innovatorhome.html")
def web2():
    name ="Hacker'z Eye "
    return render_template("innovatorhome.html", name1=name)
@app.route("/innovatorindex.html")
def back2():
    name ="Hacker'z Eye "
    return render_template("innovatorindex.html", name2=name)
@app.route("/clienthome.html")
def web3():
    name ="Hacker'z Eye "
    return render_template("clienthome.html", name2=name)
@app.route("/clientindex.html")
def back3():
    name ="Hacker'z Eye "
    return render_template("clientindex.html", name2=name)
@app.route("/createacc.html")
def web4():
    name ="Hacker'z Eye "
    return render_template("createacc.html", name2=name)
@app.route("/index.html")
def back5():
    name ="Hacker'z Eye "
    return render_template("index.html", name2=name)


if __name__=="__main__":

    app.run(debug=True)